import React from "react"
const FilterFunc = () => {
    return (
        <div className="filter-func">


        </div>
    );
}

export default FilterFunc;