# PAGES (12 pages)
1. Homepage (contains features)
2. SignUp (Register) Page
3. LogIn Page
4. Dashboard
    - Home
    - Projects
    - Create Projects Form
    - Overview
    - Task Board
    - Charts
    - Messages
    - Notes
    - Profile Page
    - TimeLine
5. Admin Portal
6. Contact US
7. About US


# Work Distribution

1. **Akash Yadav** (S20200010009)
    - Sign Up 
    - LogIn
    - Profile Page
    - Admin Portal
2. **Avinash Saroj** (S20200010027)
    - Contact US
    - About US
3. **Dushyant Yadav** (S20200010059)
    - Home
    - Projects
    - Create Project Form
    - TimeLine
4. **Naman Bhatia** (S20200010140)
    - Homepage
    - Admin Portal
    - Message 
5. **Shreyas Kasliwal** (S20200010196)
    - Overview
    - Task Board
    - Charts


# Team Info

Group no: 31

1. **Akash Yadav** (S20200010009)
2. **Avinash Saroj** (S20200010027)
3. **Dushyant Yadav** (S20200010059)
4. **Naman Bhatia** (S20200010140)
5. **Shreyas Kasliwal** (S20200010196)